#pragma once

int cb_glutinit(int w, int h, int *argcp, char *argv[], char *optArg);
